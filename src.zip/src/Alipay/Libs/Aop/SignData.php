<?php
/**
 * Created by PhpStorm.
 * User: jiehua
 * Date: 15/5/2
 * Time: 下午6:21
 */
namespace Julong\Pay\Alipay\Libs\Aop\test;
class SignData {

    public $signSourceData=null;


    public $sign=null;

} 